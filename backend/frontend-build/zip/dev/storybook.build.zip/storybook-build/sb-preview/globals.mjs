import{globals}from"./chunk-M7Z73WKF.mjs";export{globals};
